package services.Indexer;

/**
 * Created by Manthan_personal on 7/29/17.
 */
public interface Indexer {
}
