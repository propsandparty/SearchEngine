package services.CrawlAndIndex;

/**
 * Created by Manthan_personal on 9/10/17.
 */
public interface CrawlAndIndexService {



}
