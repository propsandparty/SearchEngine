package controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import play.mvc.*;

import services.SearchEngine.SearchImpl;
import views.html.*;

import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeController extends Controller {

    /**
     * An action that renders an HTML page with a welcome message.
     * The configuration in the <code>routes</code> file means that
     * this method will be called when the application receives a
     * <code>GET</code> request with a path of <code>/</code>.
     */
    private final ObjectMapper mapper = new ObjectMapper();
    public Result index() {
        return ok(index.render("Your new application is <b> NOT </b>ready."));
    }

    public Result homepage()
    {
        
        return ok(temp.render("<b>Hellow World</b>"));
    }
    public Result news()
    {

        return ok(temp.render("<b></b>"));
    }
    public CompletionStage<Result> search(String query){
        return SearchImpl.searchQuery(query,"/index").thenApply(resp->{
            JsonNode jsonNode;
            try{
                String json = mapper.writeValueAsString(resp);
                jsonNode = mapper.readTree(json);
                return ok(jsonNode);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return internalServerError();

        });

    }



}
