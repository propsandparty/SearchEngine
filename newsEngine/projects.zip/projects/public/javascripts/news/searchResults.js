define(['jquery','require', 'underscore', 'backbone', 'marionette','hbs!assets/javascripts/news/searchResults',
        'assets/javascripts/news/searchResult'],
    function ($, require,_, Backbone,marionette,template,searchResult) {
        var view =Backbone.Marionette.CompositeView.extend({
            template:template,
            childView:searchResult,
            childViewContainer:'.search_results',
            searchApi:function(){
                debugger;
                this.trigger('searchApi',$(".search_term").val());


            },
            events:{
                'click .maia-button':'searchApi',
                'change .search_term':'searchApi'
            }

        });
        return view;
    });
