define(['jquery','require', 'underscore', 'backbone', 'marionette','hbs!assets/javascripts/news/searchResult'],
    function ($, require,_, Backbone,marionette,template) {
        var view =Backbone.Marionette.View.extend({
            template:template,
            className:'result',
            events:{
                'click button':'clicked'
            },
            clicked:function(e){
                e.preventDefault();
                e.stopPropagation();
                this.trigger('search',{});
            }
        });
        return view;
    });
