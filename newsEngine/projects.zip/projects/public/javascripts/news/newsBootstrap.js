define(['jquery','require', 'underscore', 'backbone', 'marionette','hbs!assets/javascripts/news/newsBootstrap',
        'assets/javascripts/news/searchResults'],
    function ($, require,_, Backbone,marionette,template,searchResults) {
        var bootstrapper = function () {

            // var MyView = Backbone.Marionette.View.extend({
            //     template:template,// _.template('<h1><%=text%></h1>'),
            //     regions: {
            //         firstRegion: '#first-region',
            //         secondRegion: '#second-region',
            //         secondRegion: '#third-region'
            //     }
            // });
            //
            // var HomeTemplateMode=new Backbone.Model({
            //     text:'Fuck you'
            // });
            // var newView=new MyView({
            //     model:HomeTemplateMode
            // });
            // var myView = new MyView({
            //     model:HomeTemplateMode
            // });
            // myView.render();

            var news= [
                {
                    link: 'www.facebook.com',
                    snippet: 'facebook',
                    header: 'facebookHEader'
                },
                {
                    link: 'www.google.com',
                    snippet: 'google',
                    header: 'googleHeader'
                },
                {
                    link: 'www.tripadvisor.com',
                    snippet: 'tripadvisor',
                    header: 'tripadvisorHeader'
                }
            ];
            debugger;

            var resultsCollection=new Backbone.Collection(news);
            var resultsCollectionViewObj= new searchResults({
                collection:resultsCollection
            });
            resultsCollectionViewObj.listenTo(resultsCollectionViewObj,'searchApi',function(query){
                debugger;

                $.ajax({
                    url:"/news/"+query,
                    success: function(newResults){
                        console.log(newResults.results);
                        resultsCollection.reset(newResults.results);
                    }

                });

            });
            resultsCollectionViewObj.render();

            $('body').append(resultsCollectionViewObj.$el);


        };

        bootstrapper();
    });
