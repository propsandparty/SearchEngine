define(['jquery','require', 'underscore', 'backbone', 'marionette','hbs!assets/javascripts/bootstrap'],
    function ($, require,_, Backbone,marionette,template) {

        debugger;
        console.log(requirejs.s.contexts._.config );

       // var template = require('assets/javascripts/bootStrap.hbs');
        var bootstrapper = function () {

            debugger;
            var MyView = Backbone.Marionette.View.extend({
                template:template,// _.template('<h1><%=text%></h1>'),

                regions: {
                    firstRegion: '#first-region',
                    secondRegion: '#second-region',
                    secondRegion: '#third-region'
                }
            });

            var HomeTemplateMode=new Backbone.Model({
                text:'Fuck you'
            });
            var newView=new MyView({
                model:HomeTemplateMode
            });
            var myView = new MyView({
                model:HomeTemplateMode
            });
            myView.render();

            $('body').append(myView.$el);
        };

        bootstrapper();
    });
